# sCPUEdb
R package for the Shark CPUE database. The package is still in development stage and you will need a database username and password to connect to the associated PostgreSQL. Please contact Francesco Ferretti for obtaining these passwords. 
