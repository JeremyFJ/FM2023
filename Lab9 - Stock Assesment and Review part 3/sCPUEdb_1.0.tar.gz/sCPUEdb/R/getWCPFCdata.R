#' get WCPFC data from connection
#' @param con connection to the pelagic database
#' @return data.frame with lat, lon, year and hooks. It refer to all fleets fishing in the area. `Lat` and `lon` refer to the SW corner of pixel.
#' @export
getWCPFCdata = function(con){
	dat = fetch(dbSendQuery(con, statement = "select * from wcpfc;"), n = -1)
	dat$hooks = dat$hhooks*100 # because they were hundred hooks
	dat = dat[,c("yy","lat5","lon5","hooks","flag_id")]
	names(dat) = c("year","lat5","lon5","hooks","fleet")
	

	# to create lat and lon from their string values
	dat$lat = with(dat, ifelse(substr(lat5,3,3)=="S", as.numeric(substr(lat5,1,2))*-1,as.numeric(substr(lat5,1,2))))
	dat$lon = with(dat, ifelse(substr(lon5,4,4)=="W", as.numeric(substr(lon5,1,3))*-1,as.numeric(substr(lon5,1,3))))
	
	#dat = dat[dat$lat> minlat & dat$lat<=maxlat & dat$lon> minlon & dat$lon<=maxlon,]	
	# data from the eastern pacific are not available. 
	
	#years = sort(unique(dat$year))

# to set the limits on the scale
	wcpfc = with(dat, aggregate.data.frame(hooks,list(lat,lon, year, fleet),sum))
	names(wcpfc) = c("lat","lon","year","fleet","hooks")
	#wcpfc$fleet = "mixed"
	wcpfc = wcpfc[wcpfc$hooks!=0,] # there were instances with 0 hooks which should not be there
	#wcpfc$lat = wcpfc$lat+0.5 # because latitude referred to the south-west corner
	#wcpfc$lon = wcpfc$lon+0.5 # likewise - centering
	wcpfc
}	


#' get WCPFC Catch and Effort data from connection
#'
#' @param con connection to the pelagic database
#' @param code WCPFC species code. Possible values are "alb" "yft" "bet" "mls" "blm" "bum" "swo" "oth" 
#' @param index it can be either "n" (for numbers) or "c" (for metric tonnes). 
#' @return data.frame with lat, lon, year and hooks. It refer to all fleets fishing in the area. `Lat` and `lon` refer to the SW corner of pixel.
#' @export
getWCPFCdataCE = function(con, code = "yft", index = "n"){
	dat = fetch(dbSendQuery(con, statement = "select * from wcpfc;"), n = -1)
	dat$hooks = dat$hhooks*100 # because they were hundred hooks
	species = paste(code,"_",index,sep="") 
	dat = dat[,c("yy","mm","lat5","lon5","hooks","flag_id", species)]
	names(dat) = c("year","month","lat5","lon5","hooks","fleet","catch")
	

	# to create lat and lon from their string values
	dat$lat = with(dat, ifelse(substr(lat5,3,3)=="S", as.numeric(substr(lat5,1,2))*-1,as.numeric(substr(lat5,1,2))))
	dat$lon = with(dat, ifelse(substr(lon5,4,4)=="W", as.numeric(substr(lon5,1,3))*-1,as.numeric(substr(lon5,1,3))))
	
	#dat = dat[dat$lat> minlat & dat$lat<=maxlat & dat$lon> minlon & dat$lon<=maxlon,]	
	# data from the eastern pacific are not available. 
	
	#years = sort(unique(dat$year))

# to set the limits on the scale
	wcpfc = with(dat, aggregate.data.frame(dat[,c("hooks","catch")],list(lat,lon, year,month, fleet),sum))
	names(wcpfc) = c("lat","lon","year","month","fleet","hooks","catch")
#	wcpfc$fleet = "mixed"
	wcpfc = wcpfc[wcpfc$hooks!=0,] # there were instances with 0 hooks which should not be there
	#wcpfc$lat = wcpfc$lat+0.5 # because latitude referred to the south-west corner
	#wcpfc$lon = wcpfc$lon+0.5 # likewise - centering
	wcpfc
}	