#' Count Shark Species in DB
#'
#' @param con database connection from \code{connectPelagic}
#' @return value dataset with count and species
#' @export
countSpeciesData = function(con){

dat = fetch(dbSendQuery(con, statement = paste("SELECT count(species), species FROM master WHERE species ~ '^[A-Z]+' and species not in ('Species','Chondrichthyes','Carcharinidae','Carcharhinus','Carcharhinus (inshore)','Carcharhinus limbatus/tilstoni','Carcharhinus tilstoni/c. limbatus','Dipturus mennii/trachyderma','Elasmobranchii','Elasmobranchs','Isurus oxyrinchus and Lamna nasus','Scyliorhinus haeckelli/besnardi','Seiachimorpha','Seriola dumerili','Sphyrna','Squaliforms','All','All skates','All species','Barracuda','Batoidea','Batoids','Carcharhindae') and species not like '%spp.%' and species not like '%sp.%' and species not like '%idae' and species not like '%formes' and species not like '%dogfish%' and species not like 'Unidentified%' and species not like '%Unknown%' and species not like '%Total%' and species not like '%Sharks%' and species not like '%Skates%' and species not like 'Multiple%' and species not like 'Other%' and species not like 'Pelagic%' and species not like '%shark%' and species not like '%Coastal%' and species not like 'Rays%' GROUP BY species",sep="")),n = -1)

dat
}