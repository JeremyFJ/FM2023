#' Convert Database Polygon (coord) to SpatialGridDataFrame
#'
#' This function takes a `coord` string, a spatial polygon that identify a time series of data and convert it to SpatialGridDataFrame of a certain resolution (default is 5 degrees of resolution)	
#' @param coord a string identifying a spatial polygon in the sCPUE database	
#' @param Reslon longitudinal resolution
#' @param Reslat latitudinal resolution
#' @export	
	
coord2grid = function(coord, Reslon = 5, Reslat = 5){
	
	# convert coords to spatial polygons 	
	sp1 = coord2polygon(coord)
	sp1 = as.data.frame(sp1)
	sp1 = matrix(as.numeric(as.matrix(sp1)), nrow = nrow(sp1), ncol = ncol(sp1))
	SR <- sp::SpatialPolygons(list(sp::Polygons(list(sp::Polygon(sp1)), ID="r1")), proj4string=sp::CRS("+proj=longlat +ellps=WGS84"))


	## - build the Master World Grid
	cs <- c(Reslon,Reslat)
	bb = matrix(c(-180,-90,180,90), ncol =2, dimnames=list(c("lon","lat"), c("min","max"))) # bounding box for the planet
	cc <- bb[, 1] + (cs/2)  # cell offset the southernmost and westernmost point in the grid - -87.5, -177.5
	cd <- ceiling(diff(t(bb))/cs)  # number of cells per direction
	grd <- sp::GridTopology(cellcentre.offset=cc, cellsize=cs, cells.dim=cd)

	sp_grd <- sp::SpatialGridDataFrame(grd, data=data.frame(id=1:prod(cd)), 	proj4string=sp::CRS(sp::proj4string(SR))) # build the spatial grid data frame from the grid topology
	target<-sp::over(sp_grd,SR) # returns all the grid cels identified by their ids that are contained in the SR SpatialPolygon
	sp_grd = sp_grd[!is.na(target),]
	# this is a grid that has unit values in all the pixels intersecting the coord polygon
	# it can be converted to a data.frame and other variables can be added
	sp_grd
}





