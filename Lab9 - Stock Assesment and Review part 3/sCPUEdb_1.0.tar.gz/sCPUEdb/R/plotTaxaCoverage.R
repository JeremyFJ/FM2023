#' Barplot of Taxonomic Coverage
#'
#' @param dat data.frame from \code{countSpeciesData}.
#' @export 
plotTaxaCoverage = function(dat){
	dat = dat[order(dat$count),]

	dat = dat[dat$count>=50,]
	par(mfrow = c(1,1),mar=c(5,0,4,0))
	 plot(dat$count,1:length(dat$species),type="n",bty="n",axes=F,ylab="",xlab="# statistical units")
	 for(i in 1:length(dat$species)){
	 polygon(c(0,0,dat$count[i],dat$count[i]),c(i-0.45,i+0.45,i+0.45,i-0.45),col="grey")
		 if (dat$count[i]==max(dat$count)){text(max(dat$count)-1,i,dat$species[i],adj=1,font=3,cex=0.8)} else{text(dat$count[i]+1,i,dat$species[i],adj=0,font=3,cex=0.8)}
	 } 

	axis(1,at = c(seq(0,max(dat$count),50),max(dat$count)),las=1)  
}