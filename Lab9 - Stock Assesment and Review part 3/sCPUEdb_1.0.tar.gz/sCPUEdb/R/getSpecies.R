#' Get Species List from sCPUEdb Detected by a Specific Gear 
#'
#' @param con a connection to teh database. It shoud be run after `connectPelagic`.
#' @param gear gear code as listed in the master table
#' @export
getSpecies = function(con, gear = "pll"){
species = dbSendQuery(con, statement = paste("select distinct species from master where gear like '%",gear,"%';",sep=""))
data1<- fetch(species, n = -1)
species = data1$species[-grep("All|All skates|All Rays|All Sharks|Sharks|Elasmobranchii|Coastal shark|Rajiformes|sp.|spp.|group|Rays|Unknown|Other|Unidentified|disaggregate|idae",data1$species)]
species = sort(as.character(species))
species

}