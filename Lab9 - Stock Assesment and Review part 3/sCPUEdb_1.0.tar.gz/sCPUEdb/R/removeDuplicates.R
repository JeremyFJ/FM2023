#' Remove duplicates from table
#'
#' This function needs admin credentials
#' @param con connection with the sCPUEdb
#' @param query is the selections of rows from which we want to remove duplicates. This query statement allows the removal of duplicates from different selections of rows
#' @export

removeDuplicates = function(con, Table = "master", ref = "Matsunaga.solo.2007"){

query = paste("select * from ",Table," where ref = '",ref,"';", sep = "")
dat = selectData(con = con, query)
dat = unique(dat)
dbSendQuery(con, sub("select \\*","delete", query))
dbWriteTable(con, "timeseries", value=dat,append=TRUE, row.names=FALSE)	
}