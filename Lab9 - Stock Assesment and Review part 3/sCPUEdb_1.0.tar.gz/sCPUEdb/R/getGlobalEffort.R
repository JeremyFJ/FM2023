#' Build the Global Effort Data from RMFOs 
#'
#' The function fetches all the effort data  from the major 4 RMFOs: ICCAT, IOTC, WCPFC and IAATC.
#' @param con a connection to the `sCPUEdb`
#' @param Reslat latitudinal resolution.
#' @param Reslon longitudinal resolution.
#' @param fullres I want the dataset at full resolution - so all resolutions. This aspect pertains to IOTC and ICCAT data. When you have the data at full resolution you can plot the effort at the highest resolution possible with these data (1x1 degrees).
#' @export
getGlobalEffort = function(con, Reslat = 1, Reslon = 1, fullres = FALSE){

minlat = -90 
maxlat = 90
minlon = -180
maxlon = 180
ylim = c(minlat, maxlat)
xlim = c(minlon, maxlon)


##################################################
#----ICCAT

iccat = getICCATdata(con = con, fullres = fullres, Reslat = Reslat, Reslon = Reslon)
# each pixel is marked at its SW corner

###################################################
#--- WCPFC data

wcpfc = getWCPFCdata(con = con)
wcpfc$res = "5*5"
# lat and lon refer to the SW corner of pixel
# 2015 not here yet

###################################################
#--- IATTC data

iattc = getIATTCdata(con = con) 
iattc$res = "5*5"
# lat and lon refer to the SW corner of pixel
		
####################################################
#---- IOTC data

iotc = getIOTCdata(con = con, fullres = fullres, Reslat = Reslat, Reslon = Reslon)
# lat and lon refer to the SW corner of pixel
# does not have 2015 yet
datMaster = plyr::rbind.fill(iccat,wcpfc,iattc, iotc)
datMaster
}
