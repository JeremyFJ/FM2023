#' Get a table from the baseline2 machine not from the database
#'
#' it reads the source files of the database. So it check whether the data has been inputted, in that case the table is in the `data` folder, else it checks into the `datainDB` folder. This is useful to have a more synthetic view of the data populating the tables in the database. They do not include column with missing values.
#' @param Table is the table file to extract from the server
#' @param address location of the data
#' @param ref refcode of the data to explore
#' @param inDB whether the data files have been included in the postgresql database. If the function fails try this option.
#' @export

getTable = function(Table ='Master',address="data/",ref, inDB = FALSE){
 if(inDB) remoteadd = "data/datainDB/" else remoteadd = address
 system(paste("scp francesco@baseline2.stanford.edu:/home/francesco/Baselines/pelagic/",remoteadd,ref,Table,".csv /Users/francesco/Baselines/pelagic/data",sep=""))
 master = read.csv(paste("/Users/francesco/Baselines/pelagic/",address,ref,Table,".csv",sep=""))
 master
}

