#' Extract values from database table and put them into a csv file
#'
#' This function is used to edit chunks of database tables
#' @param con database connection
#' @param query the psql query to use
#' @param file csv file to output
#' @export
table2csv = function(con, query, file = "temTable.csv", openfile = TRUE){
dat = dbSendQuery(con, statement = query)
dat<- fetch(dat, n = -1)
write.csv(dat,file = file,row.names=F,na="") 
if (openfile) system("open temTable.csv")
}

#' Send csv to Database Table
#'
#' The function it is used to substitute chunks of Timeseries and Master. It takes the temTable.csv in the working directory (obtained through \code{table2csv}) and submit it to the database into the target table and for reference \code{ref}
#' @param con connection to db
#' @param ref ref code
#' @param Table target table
#' @export
csv2table = function(con, file = "temTable.csv", ref, Table = "master"){
dbSendQuery(con, statement =paste("DELETE from ",Table," where ref = '",ref,"';",sep = ""))
# this part reads the structure of the file
dat = read.csv(file)
dbWriteTable(con, Table, value=dat,append=TRUE, row.names=FALSE)	
}