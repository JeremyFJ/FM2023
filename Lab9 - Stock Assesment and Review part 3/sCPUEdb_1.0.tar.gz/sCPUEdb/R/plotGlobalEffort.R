#' Plot Global Effort Data from RMFOs 
#'
#' The function generate an enhanced version of the global effort data from \code{getGlobalEffort} as it expands pixels with a resolution coarser than 1x1 degrees. It splits the effort of any pixel into the number of 1 degree pixel contained. 
#' @param con a connection to the `sCPUEdb`
#' @param Reslat latitudinal resolution.
#' @param Reslon longitudinal resolution.
#' @param fullres I want the dataset at full resolution - so all resolutions. This aspect pertains to IOTC and ICCAT data.
#' @param year it can be "" or any given year. When year is missing then it plots the cumulative number of hooks deployed in any given pixel over the entire period for which data exist.
#' @export
plotGlobalEffort = function(con, Reslat = 1, Reslon = 1, fullres = TRUE, year = ""){
	datMaster = getGlobalEffort(con, Reslat = Reslat, Reslon = Reslon, fullres = fullres)
	datMaster2 = datMaster[!is.na(datMaster$res),] # removes lines without resolution. these data should be fixed
if (year!="") datMaster2 = datMaster2[datMaster2$year==year,] # I am using 2014 because WCPFC does not have the data at this resolution
	datMaster2 = expandRMFO(datMaster2)

	datGrid = with(datMaster2,mapplots::make.grid(x = lon, y = lat, z = hooks2, xlim=xlim,ylim =ylim,byx=1,byy=1))
	zlim = range(log(datGrid), na.rm = TRUE)

	lati = as.numeric(dimnames(datGrid)[[2]])
	long = as.numeric(dimnames(datGrid)[[1]])

	fields::image.plot(long, lati, log(datGrid), las = 1, ylab = "latitude", xlab = "longitude", main = paste("log(hooks)",year), zlim = zlim)
	
	maps::map("world", xlim = xlim, ylim = ylim, add = TRUE)
# I need to see why so many pixel;s are inland and they are not intersecting the coast
# also I need to make sure that the equator is not overestimated due to latitude sign	
	maps::map("world", xlim = xlim, ylim = ylim, fill=TRUE, add = TRUE)
}	