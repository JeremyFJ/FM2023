#' Open a Ref's PDF File
#'
#' @param projectDir project directory where you want to store the pdfs. You should create a pdf subfolder'
#' @param ref code for the publication
#' @export
openPdf = function(ref, baselineUser = "francesco", projectDir = "~/Baselines/pelagic"){
	
	x = system(paste("locate ",ref,".pdf",sep=""),intern=TRUE) # checks whether the file is present
	y = length(x) # if it is 0 there is no file
	if (y==0) { # then searches in the remote server
	#	s
	#    system(paste("rsync -a --ignore-existing -e 'ssh -p 51001' ",baselineUser,"@sharkpulse.cnre.vt.edu:/home/francesco/Baselines/pelagic/pdf/",ref,".pdf /Users/",Sys.info()['user'],"/Baselines/pelagic/pdf/",sep=""));
	system(paste("rsync -a --ignore-existing -e 'ssh -p 51001' ",baselineUser,"@sharkpulse.cnre.vt.edu:/home/francesco/Baselines/pelagic/pdf/",ref,".pdf ",projectDir,"/pdf/",sep=""));
		system(paste("open ",projectDir,"/pdf/",ref,".pdf",sep=""));
	} else system(paste("open '",x[1],"'",sep="")) 
	
}