#' Plot Available Time Periods from ICCAT
#'
#' Plots the fishing fleets and their catch data. It may take tens of seconds to run.
#' @param catchUnit whether kg for biomass and nr for numbers
#' @param code species ICCAT code
#' @export
plotTimeperiodsICCAT = function(catchUnit = "kg", code = "BSH"){
	periods = getTimeperiods(catchUnit = catchUnit, code = code)
	matper = as.matrix(periods)
	rast  = raster::raster(matper,xmn = min(as.numeric(colnames(matper))),xmx = 	max(as.numeric(colnames(matper))),ymn = 1,ymx = nrow(matper))
	par(mar = c(2,9,1,1))
	raster::image(rast, axes = F, ylab = "", useRaster = T, col = "red") # this is better
	axis(2,at=1:nrow(periods),labels = rev(rownames(periods)),las=1)
	axis(1,at=min(as.numeric(colnames(matper))):max(as.numeric(colnames(matper))))
	mtext(paste("ICCAT series for ",catchUnit, sep =""),side=3)
}	