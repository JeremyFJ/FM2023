#' Update WCPFC data
#'
#' The function updates the WCPFC data table in the \code{sCPUEdb}. It requires admin credentials and connection to the server with authentication keys. It just need the csv file name that comes from the WCPFC website.
#' @param csv csv file name holding the new data
#' @export
updateWCPFC = function(csv = "wcpfc.csv", dbuser, dbpass){

setwd("~/Baselines/pelagic/s")
con  = connectPelagic(dbuser, dbpass)
dat = dbSendQuery(con, statement = "select * from wcpfc;")

ts_classes = dbColumnInfo(dat) # get column info
classes <-ts_classes$Sclass # extracting the right classes to be inseted
classes = gsub("double|integer","numeric",classes)

dat = fetch(dat, n = -1) # get the data. I need to do that in two steps to retreive column info above.

newdat = read.csv(paste("../data/WCPFC/",csv,sep = ""))
names(newdat) = gsub("\\.","_",tolower(names(newdat)))
x = FraUtils::symdiff(names(dat),names(newdat)) # if x is 0 then the structure did not change in the update. I use symdif because it is a symmetrical setdiff. with setdiff it also 0 if the second dataset has more columns than the firts
if (length(x)==0){

	dbSendQuery(con , statement = "truncate wcpfc;") # truncate cleans a table but retains the structure

	dat = convertClasses(dat, classes)
	dbWriteTable(con, "wcpfc", value=newdat,append=TRUE, row.names=FALSE)	

	} else {print("database changed structure")}

}	