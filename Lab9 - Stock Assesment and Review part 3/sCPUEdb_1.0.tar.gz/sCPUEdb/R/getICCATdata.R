#' Get Catch and Effort data from ICCAT
#'
#' get ICCAT longline effort data from the task II catch and effort database.
#' @param con a connection to the sCPUEdb
#' @param Reslat latitudinal resolution. It is used only when fullres = FALSE. Else the resolutions are all different
#' @param Reslon longitudinal resolution
#' @param fullres if TRUE, the function gets the data pertaining to all resolutions, as they were included. So Reslat and Reslon are no more relevant.
#' @return each pixel is marked at its SW corner
#' @export	


getICCATdata = function(con, Reslat = 5, Reslon = 5, fullres = FALSE){
	# --------------------------------------------------------------
	# Query data
	dat = fetch(dbSendQuery(con, statement = "select \"DSetID\" as dsetid, \"FleetID\" as fleet,\"GearCode\" as gearcode,\"FileTypeCode\" as filetypecode,\"YearC\" as year,\"TimePeriodID\" as timeperiodid,\"Lat\" as lat,\"Lon\" as lon,\"Eff1\" as hooks,\"SquareTypeCode\" as res,\"QuadID\" as quadid from iccat.t2ce where \"Eff1Type\" = 'NO.HOOKS';"), n = -1)

	dat2 = dat[dat$res!="none",] # not sure what resolution is this - 6 records
	if (fullres==FALSE) dat2 = dat2[dat2$res==paste(Reslat,"x",Reslon, sep=""),] # filter for resolution
	dat2$res = sub("x","*", dat2$res) # having res in this form is useful for expanding the dataset later
	dat2$res = with(dat2, ifelse(fleet %in% c("003BR00","003ES00","003HN00","003US00","011IT10","021ES03"), "5*5",res)) # I have examined the interval in lat and lon of the fleets and there are some that even though report as res 1*1, the data are reported every 5 degrees. So I change the resolution to 5*5 so that they will be properly expanded and the hooks distributed across the 25 cells
	dat2 = unique(dat2) # remove duplicates and so avoid double counting of effort
						# necessary because hooks were reported twice for nr and kg

	dat2$timeperiodgroup = with(dat2,ifelse(timeperiodid<=12,"month", ifelse(timeperiodid>12 & timeperiodid<17,"trimester","year")))  

	
	dat2$lon = with(dat2,ifelse(quadid %in% c(1,2),lon,-lon)) # change the longitude west in negative
	dat2$lat = with(dat2,ifelse(quadid %in% c(1,4),lat,-lat)) # do the same for latitude south
# since I have problems with quadrants and the indices have been inputted quandradnt specifically I need to recod the latitude of squares so that they all point to the sw corner

# expanRFMO should go here because I need then to adjust the 
	ressplit = strsplit(dat2$res,"\\*")
	dat2$reslat = as.numeric(sapply(ressplit,function(x)x[1]))
	dat2$reslon = as.numeric(sapply(ressplit,function(x)x[2]))

	dat2$lat = with(dat2,ifelse(quadid %in% c(2,3), lat - reslat, lat))
	dat2$lon = with(dat2,ifelse(quadid %in% c(3,4), lon - reslon, lon))

	if (fullres) dat2 = dat2[,c("lat","lon","year","hooks","fleet","res")] else dat2 = dat2[,c("lat","lon","year","hooks","fleet")]
	
	dat2
}

#' get CPUE data
#'
#' Get CPUE data at 5x5 and monthly resolution. It selects only longline catches for a given species and does some data processing to make the time periods more explicit. It aggregates catch and effort by year and coordinate set. It also changes coordinates to their proper sign (e.g. negative for souther latitudes and western longitudes).   
#' @param catch species code "BSH" see \url{https://www.iccat.int/en/Stat_Codes.htm} for codes. 
#' @param effort effort type according to the ICCAT codes \url{https://www.iccat.int/Forms/CODES_EffortTypes.xls}.
#' @param CatchUnit either "nr" or "kg".
#' @param fleetID code according to ICCAT code. It can also be "all". \url{https://www.iccat.int/Forms/CODES_Flags-Fleets.xlsx}.
#' I am going to modify this for all resolutions
#' @export

getICCATdataCPUE = function(con, catch = "BSH", effort = "Eff1", CatchUnit = "nr", fleetID = "all"){
require(dplyr)
	# --------------------------------------------------------------
	# Query data
	if(fleetID=="all") fleetCond = "" else fleetCond = paste(" and \"FleetID\" = '",fleetID,"'",sep = "")
	if(CatchUnit=="all") catchCond = "" else catchCond = paste(" and \"CatchUnit\" = '",CatchUnit,"'",sep = "")

	dat = fetch(dbSendQuery(con, statement = paste("select * from iccat.t2ce where \"Eff1Type\" = 'NO.HOOKS'", catchCond, fleetCond,";",sep="")), n = -1)
	
	dat2 = dat[,c("DSetID","FleetID","GearCode","FileTypeCode","YearC","TimePeriodID","Lat","Lon",c(catch, effort),"SquareTypeCode","QuadID")] 
	#dat2 = unique.data.frame(dat2) # remove duplicates 
									# from 244,272 rows to  158,478
 
 
	dat2$timeperiodgroup = with(dat2,ifelse(TimePeriodID<=12,"Month", ifelse(TimePeriodID>12 & TimePeriodID<17,"Trimester","year")))  
	dat2$res = sub("x","*", dat2$SquareTypeCode)
	
	dat2$lon = with(dat2,ifelse(QuadID %in% c(1,2),Lon,-Lon)) # change the longitude west in negative
	dat2$lat = with(dat2,ifelse(QuadID %in% c(1,4),Lat,-Lat)) # do the same for latitude south
# since I have problems with quadrants and the indices have been inputted quandradnt specifically I need to recod the latitude of squares so that they all point to the sw corner
	
	ressplit = strsplit(dat2$res,"\\*")
	dat2$reslat = as.numeric(sapply(ressplit,function(x)x[1]))
	dat2$reslon = as.numeric(sapply(ressplit,function(x)x[2]))
	
	dat2$lat = with(dat2,ifelse(QuadID %in% c(2,3), lat - reslat, lat))
	dat2$lon = with(dat2,ifelse(QuadID %in% c(3,4), lon - reslon, lon))
 
	dat2 = with(dat2,aggregate(dat2[,c(catch,effort)],list(lat,lon,YearC,TimePeriodID,res,FleetID),sum))
names(dat2) = c("lat","lon","year","month","res","fleet",paste(c(quote(catch),quote(effort))))
	
	dat2
	
}



	