#' Convert classes of a data.frame columns to specified kind 
#'
#' @param df data.frame
#' @param classes vector of classes
#' @export
convertClasses <- function(df,classes){
  		out <- lapply(1:length(classes),
        FUN = function(classIndex){as(df[,classIndex],classes[classIndex])})
  		names(out) <- colnames(df)
  		return(data.frame(out))
}