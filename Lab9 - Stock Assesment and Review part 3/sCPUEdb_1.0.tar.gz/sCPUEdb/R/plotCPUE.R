#' Plot CPUEs for a given species
#'
#' @param con connection to the database
#' @param species species names
#' @param region large oceanic region as codified in regions table. It could be a part of the entire name as it will be used in the clause like '\%",region,"\%' 
#' @param index index of abundance to plot
#' @param dat optional is the supplied dataset from an external query
#' @export
plotCPUE = function(con, species = "Prionace glauca", region = "Indian", index = "scpue", dat = NULL){
	require(RColorBrewer)
	

	if (is.null(dat)){
		query = paste("select ",index,",l",index,",u",index,", year, ref from timeseries where region like '%",region,"%' and species = '",species,"' and ",index," is not NULL and ref not in ('Cramer.Adams.1999');",sep = "")
	
		dat = fetch(dbSendQuery(con, statement = query), n = -1)
		if (nrow(dat)==0) stop("query has no results")
	} else dat = dat
	
	#colors = rainbow(length(unique(dat$ref)))
	colors = colorRampPalette(brewer.pal(11,"Spectral"))(length(unique(dat$ref)))
	dat2 = data.frame(ref = unique(dat$ref), colors = colors)
	dat = merge(dat,dat2, by="ref", all.x=T)
	#attach(dat)
	
	if (sum(dat$uscpue,na.rm = T)>0) ylim = c(0,max(dat$uscpue,na.rm = T)) else ylim = c(0, max(dat$scpue,na.rm = T))
	plot(scpue~year,data = dat, pch=16, axes = F, ylim = ylim, xlim = range(year), col = as.character(dat$colors))
	if (sum(dat$uscpue,na.rm = T)>0) with(dat,segments(year,lscpue,year,uscpue))
	axis(1)
	axis(2,las = 1)
	mtext(region, side = 3)
	legend(min(dat$year),max(ylim),legend = dat2$ref, fill = as.character(dat2$colors), bty="n")
}