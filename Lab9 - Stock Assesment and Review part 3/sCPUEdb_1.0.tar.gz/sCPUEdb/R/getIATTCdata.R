#' get IATTC longline data from local file
#'
#' This csv file needs to be included in the database. The data is only for longline. Need to produce a similar function for purse seine.
#' @param con a connection to the sCPUEdb
#' @param bbox bounding box. It can be c(minlat,maxlat,minlon,maxlon) or NULL
#' @return lat and lon refer to the SW corner of pixel
#' @export
getIATTCdata = function(con, bbox = NULL){
	# bbox = c(0,90,-180,-70)
	minlat = bbox[1]
	maxlat = bbox[2]
	minlon = bbox[3]
	maxlon = bbox[4]

dat = fetch(dbSendQuery(con, statement = "select * from iattc;"), n = -1)

dat = dat[,c("year","latc5","lonc5","hooks","flag")] # select only necessary columns
names(dat) = c("year","latc5","lonc5","hooks","fleet")
	
	# to create lat and lon from their string values
	dat$lat = dat$latc5
	dat$lon = dat$lonc5
	
	if (!is.null(bbox)) dat = dat[dat$lat> minlat & dat$lat<=maxlat & dat$lon> minlon & dat$lon<=maxlon,]	
	years = sort(unique(dat$year))
	# to set the limits on the scale
	iattc = with(dat, aggregate.data.frame(hooks,list(lat,lon, year,fleet),sum))
	names(iattc) = c("lat","lon","year","fleet","hooks")
	iattc$lat = iattc$lat-2.5 # because latitude referred to the center of the pixel, to make it comparable to wfcpc it needs to be on south west corner of the pixel
	iattc$lon = iattc$lon-2.5 # likewise - centering
	iattc
}	

#' get IATTC longline Catch and Effort data for a certain species
#'
#' This csv file needs to be included in the database. The data is only for longline. Need to produce a similar function for purse seine.
#' @param con a connection to the sCPUEdb
#' @param bbox bounding box. It can be c(minlat,maxlat,minlon,maxlon) or NULL
#' @param code IATTC species code. It can be "alb", "bet", "pbf", "skj", "tun", "yft", "bil", "blm", "bum", "mls", "sfa", "ssp", "swo".
#' @param index can be 'n' for numbers and 'mt' for biomass
#' @return lat and lon refer to the SW corner of pixel
#' @export
getIATTCdataCE = function(con, code = "alb", index = "n"){

	
	varcatch = paste(code,index, sep="")
dat = fetch(dbSendQuery(con, statement = "select * from iattc;"), n = -1)

dat = dat[,c("year","month","latc5","lonc5","hooks","flag",varcatch)] # select only necessary columns
names(dat) = c("year","month","lat","lon","hooks","fleet", "catch")
	
	
	years = sort(unique(dat$year))
	# to set the limits on the scale
	iattc = with(dat, aggregate.data.frame(dat[,c("catch","hooks")],list(lat,lon, year,month,fleet),function(x)sum(x, na.rm = TRUE)))
	names(iattc) = c("lat","lon","year","month","fleet","catch","hooks")
	iattc$lat = iattc$lat-2.5 # because latitude referred to the center of the pixel, to make it comparable to wfcpc it needs to be on south west corner of the pixel
	iattc$lon = iattc$lon-2.5 # likewise - centering
	iattc
}	

