#' expand RMFO dataset to full resolution
#' 
#' It expands all catches to 1 degree cell in latitude and longitude. It takes a pixel of any size in degres and expand the correspondent row in dat to a number of rows equal to the number of 1 degree pixels contained in this larger pixel identified by res  
#' @param dat a dataset with a res (resolution, e.g. 5*5) field. dat should have a lat and lon field too. 
#' @export
expandRMFO = function(dat){
	ressplit = strsplit(dat$res,"\\*")
	dat$reslat = as.numeric(sapply(ressplit,function(x)x[1]))
	dat$reslon = as.numeric(sapply(ressplit,function(x)x[2]))
	dat$pixels = sapply(dat$res,function(x)eval(parse(text = sub("x","*",x))))
	df.exp <- dat[rep(row.names(dat), dat$pixels),]
	df.exp$hooks2 = with(df.exp,hooks/pixels) # redistribute effort equally across smaller pixels
	df.exp$lat = unlist(mapply(function(x, y, z) rep(seq(x, x+y-1),z),dat$lat,dat$reslat, dat$reslon, SIMPLIFY=F)) # I need to use simplify = F, otherwise I do not get a vector when I unlist
	df.exp$lon = unlist(mapply(function(x, y, z) rep(seq(x, x+y-1),each = z),dat$lon,dat$reslon, dat$reslat,SIMPLIFY=F))
	df.exp
		}
		
#' expand RMFO dataset to full resolution
#' 
#' It expands all catches to Reslat by Reslon degree cell in latitude and longitude. It takes a pixel of any size in degrees and expand the correspondent row in `dat` to a number of rows equal to the number of Reslat degree pixels contained in this larger pixel identified by dat$res  
#' @param dat a dataset with a res (resolution, e.g. 5*5) field. dat should have a lat and lon field too.
#' param Reslat terget resolution for the expanded dataset
#' param Reslon target resolution for the expanded dataset. It works if Reslat = Reslon 
#' @export		
		
expandRMFO2 = function(dat, Reslat, Reslon){
# select data points with resolution < than Reslat (or Reslon)
	ressplit = strsplit(dat$res,"\\*")
	dat$reslat = as.numeric(sapply(ressplit,function(x)x[1]))
	dat$reslon = as.numeric(sapply(ressplit,function(x)x[2]))
	df0 = dat[dat$reslat<Reslat,]
	df0$pixels = 1
	df0$lat = floor(df0$lat/Reslat)*Reslat
	df0$lon = floor(df0$lon/Reslon)*Reslon
	df0$res = paste(Reslat,"*",Reslon,sep = "")
	df0$hooks2 = df0$hooks
# expand data points with resolution >= Reslat 	
	dat = dat[dat$reslat>=Reslat,]
	dat$pixels = sapply(dat$res,function(x)eval(parse(text = sub("x","*",x))))
	dat$pixels = dat$pixels/(Reslat*Reslon)
	df.exp <- dat[rep(row.names(dat), dat$pixels),]
	df.exp$hooks2 = with(df.exp,hooks/pixels) # redistribute effort equally across smaller pixels
	df.exp$lat = unlist(mapply(function(x, y, z) rep(seq(x, x+y-Reslat,Reslat),z/Reslon),dat$lat,dat$reslat, dat$reslon, SIMPLIFY=F)) # I need to use simplify = F, otherwise I do not get a vector when I unlist
	df.exp$lon = unlist(mapply(function(x, y, z) rep(seq(x, x+y-Reslon, Reslon),each = z/Reslat),dat$lon,dat$reslon, dat$reslat,SIMPLIFY=F))
# put together the datasets
	df.exp = rbind(df0,df.exp)
	df.exp
	
		}		
		
		