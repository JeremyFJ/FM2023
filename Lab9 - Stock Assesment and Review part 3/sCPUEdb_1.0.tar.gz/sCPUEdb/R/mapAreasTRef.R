#' Map all polygons pertaining to a single ref
#'
#' @param con connection object
#' @param ref reference code
#' @export
mapAreasTRef = function(con, ref){ # map areas together by ref
	require(mapdata)
	area = dbSendQuery(con, statement = paste("select ref,area,coord from master where coord is not NULL and ref  = '",ref,"';",sep=""))
	data1<- fetch(area, n = -1)
	data1 = unique(data1)
	
	coords = data1$coord
	map("worldHires", mar=c(3,1,3,1),oma = c(1,1,1,1),main = ref)
	for (i in 1:length(coords)){
		if (data1$ref[i] %in% c("Francis.etal.2002","Roman-Verdesoto.Zoller.2005","Yokota.etal.2006","Baeta.etal.2010")) next
		# coords are inverted need to be fixed
		prova = coords[i]
		sp1 = coord2polygon(prova)
		sp1 = as.data.frame(sp1)
		sp1 = matrix(as.numeric(unlist(sp1)),nrow = nrow(sp1), ncol = ncol(sp1))
		SR <- SpatialPolygons(list(Polygons(list(Polygon(sp1)), ID="r1")),
 proj4string=CRS("+proj=longlat +ellps=WGS84"))
		rSR = recenter(SR)
		plot(rSR, add=T, col = "blue")	
			
		
# 		x = gregexpr('\\-*[0-9]+\\.*[0-9]*\\,',prova,perl=T,fixed=F) # extracts longitudes	
# 		lon = unlist(regmatches(prova,x))
# 		lon = gsub(",","",lon)
# 
# 		y = gregexpr('\\,\\-*[0-9]+\\.*[0-9]*',prova,perl=T) # extracts longitudes
# 		lat = unlist(regmatches(prova,y))
# 		lat = gsub(",","",lat)
# 		if (data1$ref[i] %in% c("Francis.etal.2002","Roman-Verdesoto.Zoller.2005","Yokota.etal.2006","Baeta.etal.2010")){lat2 = lon; lon2 = lat; lon = lon2; lat = lat2}
# 		polygon(lon,lat,col="blue")
		
		
		#text(20,-80,data1$ref[i])
		# need to remove the comas
}
	map("worldHires",add=T,fill=T, mar=c(3,1,3,1),oma = c(1,1,1,1))
	mtext(ref, side = 3)

}