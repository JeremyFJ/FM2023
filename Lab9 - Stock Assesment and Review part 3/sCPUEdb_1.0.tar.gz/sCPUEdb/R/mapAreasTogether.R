#' Map all Polygons Together
#'
#' All polygons drawn together on a global map
#' @param con connection to database
#' @param refs list of studies to plot given by a vector of reference codes.
#' @export
mapAreasTogether = function(con, refs = NULL){
	require(mapdata)
	if(is.null(refs)) area = dbSendQuery(con, statement = paste("select ref,area,coord from master where coord is not NULL;",sep="")) else area = dbSendQuery(con, statement = paste("select ref,area,coord from master where ref in ('",paste(refs,collapse = "','"),"');",sep=""))
	data1<- fetch(area, n = -1)
	data1 = unique(data1)
	coords = data1$coord

	map("worldHires", mar=c(3,1,3,1),oma = c(1,1,1,1))
	for (i in 1:length(coords)){
		
		if (data1$ref[i] %in% c("Francis.etal.2002","Roman-Verdesoto.Zoller.2005","Yokota.etal.2006","Baeta.etal.2010")) next # coords are inverted so they need to be fixed
		if (is.na(coords[i])) next
		prova = coords[i]

		sp1 = coord2polygon(prova)
		sp1 = as.data.frame(sp1)
		sp1 = matrix(as.numeric(unlist(sp1)),nrow = nrow(sp1), ncol = ncol(sp1))
		SR <- SpatialPolygons(list(Polygons(list(Polygon(sp1)), ID="r1")),
 proj4string=CRS("+proj=longlat +ellps=WGS84"))
		rSR = recenter(SR)
		plot(rSR, add=T, col = "blue")	
		
	}

	map("worldHires",add=T,fill=T, mar=c(3,1,3,1),oma = c(1,1,1,1))

}