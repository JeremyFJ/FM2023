#' Create Connection to Pelagic Database on Baseline3. 
#'
#' Create Connection to Pelagic Database on Baseline3.
#' This connection grant permission to select on tables: master, timseries, iccatt2ce, iotccell, wcpfc, iattc. 
#' @param dbuser role name for database
#' @param dbpass database password for role `dbuser`
#' @examples
#' con = connectPelagic()
#' dat = selectData(con, "select * from master limit1")
#' dat
#' @export
connectPelagic = function(dbuser, dbpass){
  require(RPostgreSQL)
  require(RH2) 	
  	dbname = "pelagic"
  	dbhost <- "sharkpulse.cnre.vt.edu"
  	dbport <- 5432
  	drv <- dbDriver("PostgreSQL") 
  	con <- dbConnect(drv, host=dbhost, port=dbport, dbname=dbname,  user=dbuser, password=dbpass
  	) 
}