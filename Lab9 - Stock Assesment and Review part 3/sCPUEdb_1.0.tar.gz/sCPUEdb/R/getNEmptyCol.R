#' Get Table with Non-Empty columns. 
#'
#' The function query the database for a specific db table and ref, and returns a data.frame with non-empty columns.
#' @param con connection to the database
#' @param query sql query to select data
#' @param Table table name of the shark CPUE database
#' @export
getNEmptyCol = function(con,query,Table = "master"){
	#data1<- fetch(dbSendQuery(con, statement = paste("select * from ",Table," where ref = '",ref,"';",sep="")), n = -1)
	data1<- fetch(dbSendQuery(con, statement = query), n = -1)
	m1<-apply(data1,2,function(x)ifelse(is.na(x),0,1))
	data2 = data1[,colSums(m1)>0]
	data2
}