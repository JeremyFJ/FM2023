#' extract the name of the table or figure
#'
#' it is use by ExtractCatches
#' @param cell text tring containing the figure/table names
#' @export
getMaterial = function(cell){
	
	st = regexpr("[T|t]ab[a-z]*\\d?[a-z]*|Fig[a-z]*\\d?[a-z]*",cell,perl=T) # parse the cell with the material - this is not needed actually
	material = gsub("ure|le","",cell) # since Tables and Figures in many files are abbreviated and within cells arte in long form I need to abbreviate them
	st = regexpr("[T|t]ab\\d+\\w*|Fig\\d+\\w*",material) # parse the material in cell
	stp = attributes(st)$match.length # get the stop position of the parsed word
	material = substr(material,st,stp) # assigns the word to the material
}