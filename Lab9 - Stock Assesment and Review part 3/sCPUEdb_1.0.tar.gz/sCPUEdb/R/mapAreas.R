#' Map all areas in the database. 
#'
#' The function builds a multipage pdf that shows all the areas in the sCPUEdb (one polygon and map per page).
#' @param con a pelagic database connection
#' @export
mapAreas = function(con){ # so in this way con has to run once
require(mapdata)
area = dbSendQuery(con, statement = paste("select ref,area,coord from master where coord is not NULL order by ref;",sep=""))
data1<- fetch(area, n = -1)
data1 = unique(data1)
coords = data1$coord


pdf(paste("../maps/mapPolygons",format(Sys.time(),"%d%m%Y"),".pdf",sep=""))

for (i in 1:length(coords)){
#for (i in 51:60){
	map("worldHires")
	prova = coords[i]
		
		if (data1$ref[i] %in% c("Francis.etal.2002","Roman-Verdesoto.Zoller.2005","Yokota.etal.2006","Baeta.etal.2010")) next # coords are inverted so they need to be fixed
		if (is.na(coords[i])) next
		

		sp1 = coord2polygon(prova)
		sp1 = as.data.frame(sp1)
		sp1 = matrix(as.numeric(unlist(sp1)),nrow = nrow(sp1), ncol = ncol(sp1))
		if (nrow(sp1)<=1) {points(sp1,pch=16, col = "blue"); mtext(data1$ref[i],3); next}
		SR <- SpatialPolygons(list(Polygons(list(Polygon(sp1)), ID="r1")),
 proj4string=CRS("+proj=longlat +ellps=WGS84"))
		rSR = recenter(SR)
		if (abs(min(sp1[,1]) - max(sp1[,1])) > 180) plot(rSR, add=T, col = "blue")	else plot(SR, add=T, col = "blue")
		
	

# 	polygon(lon,lat,col="red")
	mtext(data1$ref[i],3)
	#map("worldHires",col="grey",add=T,fill=T)
# need to remove the comas
}

dev.off()
}











