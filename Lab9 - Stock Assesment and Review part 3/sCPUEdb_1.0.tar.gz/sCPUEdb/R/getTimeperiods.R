#' Get Time Periods from the ICCAT Schema.
#'
#' It lists the fishing fleets and their catch data. It may take tens of seconds to run.
#' @param catchUnit whether kg for biomass and nr for numbers
#' @param code species ICCAT code
#' @export

getTimeperiods = function(catchUnit = "kg", code = "BSH"){

	flagnames = fetch(dbSendQuery(con, statement = paste("select distinct \"FlagName\" from iccat.\"Flags\";",sep="")), n = -1)
	
	flagnames = sort(as.vector(flagnames$FlagName))
	
	# dealing with apostrophes. since it caused only by Cote D'Ivoire. I will eliminate it for now
	flagnames = gsub("'","", flagnames) # I can remove the problematic '
	years = fetch(dbSendQuery(con, statement = "select distinct \"YearC\" from iccat.t2ce;"), n=-1)
# build an empty matrix of time periods for each flag
periods = matrix(NA,nrow = length(flagnames),ncol = length(min(years):max(years)),dimnames = list(flagnames,min(years):max(years)))

	for (i in 1:length(flagnames)){
		dat = fetch(dbSendQuery(con, statement = paste("select distinct(\"YearC\") from iccat.t2ce where \"GearGrpCode\" = 'LL' and \"FleetID\" in (select \"FleetID\" from iccat.\"Flags\" where \"FlagName\" = '",flagnames[i],"') and \"CatchUnit\" = '",catchUnit,"' and \"",code,"\">0;",sep="")), n = -1)
		if(nrow(dat)==0) next
		years = dat$YearC
		periods[flagnames[i],as.character(years)] = 1
	}

# let's pick only the nation with data available
	datavail = rowSums(periods,na.rm=T)
	nations = names(datavail[datavail>0])
	periods = periods[nations,colSums(periods,na.rm=T)>0]
	periods
}

#' Get Time Periods from the Master Table.
#'
#' It lists the fishing fleets and their catch data
#' @param index index of abundance
#' @param species species scientific name
#' @export

getTimeperiodsSB = function(index = "bpue", species = "Prionace glauca"){
	flagnames = dbSendQuery(con, statement = paste("select distinct fleet from master;",sep=""))
	flagnames = fetch(flagnames, n = -1)
	fleets = as.vector(flagnames$fleet)

}

